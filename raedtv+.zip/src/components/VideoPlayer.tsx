import React, { useEffect, useRef, useState } from 'react';
import Hls from 'hls.js';
import { X, Play, Pause, Loader2 } from 'lucide-react';

interface VideoPlayerProps {
  channel: { id?: string; title: string; directUrl: string; logo?: string } | null;
  channels: any[];
  onSelectChannel: (channel: any) => void;
  onClose: () => void;
}

export function VideoPlayer({ channel, channels, onSelectChannel, onClose }: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [showUI, setShowUI] = useState(true);
  const [error, setError] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  let uiTimeout: ReturnType<typeof setTimeout>;

  useEffect(() => {
    if (!channel || !videoRef.current) return;
    setIsLoading(true);
    setError(false);

    const video = videoRef.current;
    let hls: Hls | null = null;

    const hideUI = () => setShowUI(false);
    clearTimeout(uiTimeout);
    uiTimeout = setTimeout(hideUI, 3000);

    if (Hls.isSupported()) {
      hls = new Hls({
        maxBufferLength: 30,
        enableWorker: true,
      });
      if (channel.directUrl) {
        hls.loadSource(channel.directUrl.trim());
      } else {
        hls.loadSource('');
      }
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        video.play().catch(() => setIsPlaying(false));
        setIsLoading(false);
      });
      hls.on(Hls.Events.ERROR, (event, data) => {
        if (data.fatal) {
          setError(true);
          setIsLoading(false);
          setTimeout(() => onClose(), 5000); // Close after 5s on fatal error
        }
      });
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      video.src = channel.directUrl ? channel.directUrl.trim() : '';
      video.addEventListener('loadedmetadata', () => {
        video.play().catch(() => setIsPlaying(false));
        setIsLoading(false);
      });
      video.addEventListener('error', () => {
        setError(true);
        setIsLoading(false);
        setTimeout(() => onClose(), 5000);
      });
    }

    return () => {
      clearTimeout(uiTimeout);
      if (hls) hls.destroy();
    };
  }, [channel]);

  if (!channel) return null;

  const togglePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleScreenTap = () => {
    setShowUI(!showUI);
    clearTimeout(uiTimeout);
    if (!showUI) {
      uiTimeout = setTimeout(() => setShowUI(false), 3000);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center transition-opacity"
      onClick={handleScreenTap}
    >
      {error ? (
        <div className="absolute inset-0 flex items-center justify-center bg-black z-50">
          <div className="text-white text-xl font-bold flex flex-col items-center">
            <span className="mb-4">کەناڵەکە لە کار کەوتووە</span>
            <Loader2 className="animate-spin text-purple-500" size={48} />
          </div>
        </div>
      ) : null}

      <video 
        ref={videoRef}
        className="w-full h-full object-contain"
        playsInline
        onWaiting={() => setIsLoading(true)}
        onPlaying={() => setIsLoading(false)}
      />

      {/* Loading Indicator */}
      {isLoading && !error && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-40">
           <Loader2 className="animate-spin text-purple-500" size={48} />
        </div>
      )}

      {/* UI Overlay */}
      <div 
        className={`absolute inset-0 pointer-events-none transition-opacity duration-300 flex flex-col justify-between ${showUI ? 'opacity-100' : 'opacity-0'}`}
        style={{ backgroundImage: 'linear-gradient(to bottom, rgba(0,0,0,0.8) 0%, transparent 20%, transparent 80%, rgba(0,0,0,0.8) 100%)' }}
      >
        {/* Header */}
        <div className="p-6 flex items-center justify-between z-50 pointer-events-auto">
          <div className="flex flex-col">
            <span className="text-white font-bold text-lg">{channel.title}</span>
            <span className="text-red-500 text-xs font-bold flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
              ڕاستەوخۆ
            </span>
          </div>
          <button 
            onClick={(e) => { e.stopPropagation(); onClose(); }}
            className="p-3 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-md transition"
          >
            <X size={24} className="text-white" />
          </button>
        </div>

        {/* Center Play Button */}
        <div className="flex-1 flex items-center justify-center pointer-events-auto">
          <button 
            onClick={togglePlay}
            className="p-6 rounded-full bg-black/40 hover:bg-black/60 backdrop-blur-md border border-white/10 text-white transition-transform active:scale-95"
          >
            {isPlaying ? <Pause size={40} /> : <Play size={40} className="ml-2" />}
          </button>
        </div>

        {/* Horizontal Channels Bar */}
        <div className="p-4 bg-black/60 backdrop-blur-[50px] border-t border-white/10 w-full overflow-x-auto pb-8 pointer-events-auto z-50">
          <div className="flex gap-4">
            {channels.map(c => (
              <button 
                key={c.id} 
                onClick={(e) => { e.stopPropagation(); onSelectChannel(c); }}
                className={`flex-shrink-0 w-16 h-16 rounded-2xl overflow-hidden border-2 transition-all ${c.id === channel.id ? 'border-purple-500 scale-110 shadow-[0_0_15px_rgba(168,85,247,0.6)]' : 'border-transparent opacity-70 hover:opacity-100 hover:scale-105'}`}
              >
                <img src={c.logo} alt={c.title} className="w-full h-full object-cover bg-black" />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
