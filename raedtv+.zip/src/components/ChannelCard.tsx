import React from 'react';
import { Heart } from 'lucide-react';

interface Channel {
  id: string;
  title: string;
  logo: string;
  directUrl: string;
}

interface ChannelCardProps {
  channel: Channel;
  isFavorite: boolean;
  onToggleFavorite: (e: React.MouseEvent) => void;
  onClick: () => void;
}

export const ChannelCard: React.FC<ChannelCardProps> = ({ channel, isFavorite, onToggleFavorite, onClick }) => {
  return (
    <div 
      onClick={onClick}
      className="relative aspect-square rounded-2xl overflow-hidden border border-white/10 cursor-pointer active:scale-95 transition-transform bg-black/50 backdrop-blur-md"
      style={{
        backgroundImage: `url('https://image2url.com/images/1765276781238-2cb7161e-6649-4e90-a06e-1175d97e9018.png')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundBlendMode: 'overlay'
      }}
    >
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent z-0"></div>
      
      {/* Favorite Button */}
      <button 
        onClick={onToggleFavorite}
        className="absolute top-2 right-2 z-10 p-2 rounded-full bg-black/40 backdrop-blur-sm border border-white/5"
      >
        <Heart 
          size={18} 
          className="transition-colors" 
          stroke={isFavorite ? 'none' : 'currentColor'} 
          fill={isFavorite ? '#eab308' : 'none'} 
        />
      </button>

      {/* Logo */}
      <div className="absolute inset-0 flex items-center justify-center p-4 z-0">
        <img 
          src={channel.logo} 
          alt={channel.title} 
          className="w-full h-full object-contain filter drop-shadow-lg"
          onError={(e) => {
             e.currentTarget.style.display = 'none';
             e.currentTarget.parentElement!.innerHTML = '<div class="w-8 h-8 rounded-full border-2 border-purple-500 border-t-transparent animate-spin"></div>';
          }}
        />
      </div>

      {/* Title */}
      <div className="absolute bottom-2 left-0 right-0 text-center z-10 px-1">
        <span className="text-sm font-bold text-white drop-shadow-md truncate block">
          {channel.title}
        </span>
      </div>
    </div>
  );
}
