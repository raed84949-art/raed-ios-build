import React, { useState, useEffect } from 'react';
import { User, MapPin, Heart, Home as HomeIcon, Search, Shield, Play } from 'lucide-react';
import { rtdb } from './firebase';
import { ref, onValue } from 'firebase/database';
import { ChannelCard } from './components/ChannelCard';
import { VideoPlayer } from './components/VideoPlayer';

// Types
interface Channel {
  id: string;
  title: string;
  logo: string;
  directUrl: string;
}

export default function App() {
  const [stage, setStage] = useState<'splash' | 'gps' | 'activation' | 'main'>('splash');
  const [gpsStatus, setGpsStatus] = useState<'idle' | 'checking' | 'passed' | 'failed'>('idle');
  const [activationCode, setActivationCode] = useState('');
  const [activeTab, setActiveTab] = useState<'home' | 'favorites' | 'location' | 'profile'>('home');
  const [isOffline, setIsOffline] = useState(false);
  
  // Data
  const [channels, setChannels] = useState<Channel[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [playingChannel, setPlayingChannel] = useState<Channel | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('هەمووی');

  // Compute categories
  const categories = ['هەمووی', ...Array.from(new Set(channels.map(c => (c as any).category || 'گشتی')))];

  // 1. Splash Screen & Offline Detection
  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    setIsOffline(!navigator.onLine);

    const timer = setTimeout(() => {
      setStage('gps');
    }, 4000); // Increased slightly for the new animation
    return () => {
      clearTimeout(timer);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const requestLocation = () => {
    setGpsStatus('checking');
    if (!('geolocation' in navigator)) {
      setGpsStatus('failed');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude: lat, longitude: lon } = position.coords;
        // Expanded bounding box for Iraq to ensure no edge cases fail
        if (lat >= 28.0 && lat <= 38.0 && lon >= 38.0 && lon <= 49.0) {
          setGpsStatus('passed');
          setTimeout(() => setStage(localStorage.getItem('raedtv_active') === 'true' ? 'main' : 'activation'), 1500);
        } else {
          setGpsStatus('failed');
        }
      },
      (error) => {
        console.error("GPS Error:", error);
        setGpsStatus('failed'); // Denied or error
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
    );
  };

  // 2. GPS Logic initialization
  useEffect(() => {
    if (stage === 'gps') {
       setGpsStatus('idle'); // Wait for user action
    }
  }, [stage]);

  // Load favorites
  useEffect(() => {
    const saved = localStorage.getItem('raed_favorites');
    if (saved) setFavorites(JSON.parse(saved));
  }, []);

  // Fetch Channels
  useEffect(() => {
    if (stage === 'main') {
      const channelsRef = ref(rtdb, 'liveChannels');
      onValue(channelsRef, (snapshot) => {
        const data = snapshot.val();
        if (data) {
          const loaded: Channel[] = Object.keys(data).map(key => ({
            id: key,
            ...data[key]
          }));
          setChannels(loaded);
        } else {
          setChannels([]);
        }
      });
    }
  }, [stage]);

  const handleActivation = () => {
    if (activationCode.toLowerCase() === 'raedtv26') {
      localStorage.setItem('raedtv_active', 'true');
      setStage('main');
    } else {
      alert('کۆدەکە هەڵەیە');
    }
  };

  const toggleFavorite = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    let updated;
    if (favorites.includes(id)) {
      updated = favorites.filter(f => f !== id);
    } else {
      updated = [...favorites, id];
    }
    setFavorites(updated);
    localStorage.setItem('raed_favorites', JSON.stringify(updated));
  };

  if (isOffline) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center text-white p-6 text-center">
        <h1 className="text-2xl font-bold">کێشە لەهێڵی ئینتەرنێت هەیە</h1>
      </div>
    );
  }

  if (stage === 'splash') {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center relative overflow-hidden">
        {/* Background Gradients */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-purple-900/40 via-black to-black z-0"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-purple-600 rounded-full blur-[120px] opacity-20 animate-pulse"></div>
        
        {/* Particle/Star effect background via CSS */}
        <div className="absolute inset-0 z-0 opacity-30" style={{ backgroundImage: 'radial-gradient(circle, #fff 1px, transparent 1px)', backgroundSize: '40px 40px' }}></div>
        
        <div className="z-10 flex flex-col items-center">
          <div className="relative mb-8">
            {/* Rotating glowing rings */}
            <div className="absolute inset-[-20px] rounded-full border border-purple-500/30 animate-[spin_4s_linear_infinite]"></div>
            <div className="absolute inset-[-40px] rounded-full border border-purple-400/20 animate-[spin_6s_linear_infinite_reverse]"></div>
            <div className="absolute inset-[-60px] rounded-full border border-white/10 animate-[spin_8s_linear_infinite]"></div>
            
            {/* Center Glow */}
            <div className="absolute inset-0 bg-purple-500/20 rounded-full blur-xl animate-ping opacity-60 duration-1000"></div>
            
            {/* Logo Image */}
            <img 
              src="https://image2url.com/images/1765276673899-f93a46b6-20a3-454c-ac94-202022d4dd2d.png" 
              alt="RaedTV+ Logo" 
              className="w-48 h-48 object-contain drop-shadow-[0_0_25px_rgba(168,85,247,0.8)] relative z-10"
            />
          </div>
          
          {/* Title */}
          <h1 className="text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-white to-purple-400 tracking-[0.2em] drop-shadow-2xl animate-pulse">
            RAEDTV<span className="text-purple-500">+</span>
          </h1>
          
          {/* Subtitle / Loading */}
          <p className="mt-4 text-purple-300/80 tracking-widest text-sm uppercase">پریمیم تەلەفزیۆن</p>
          
          {/* Loading Dots */}
          <div className="mt-12 flex gap-3">
            <div className="w-3 h-3 bg-purple-500 rounded-full animate-bounce shadow-[0_0_10px_rgba(168,85,247,1)]"></div>
            <div className="w-3 h-3 bg-fuchsia-500 rounded-full animate-bounce shadow-[0_0_10px_rgba(217,70,239,1)]" style={{ animationDelay: '0.2s' }}></div>
            <div className="w-3 h-3 bg-white rounded-full animate-bounce shadow-[0_0_10px_rgba(255,255,255,1)]" style={{ animationDelay: '0.4s' }}></div>
          </div>
        </div>
      </div>
    );
  }

  if (stage === 'gps') {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center p-6 text-white relative"
           style={{ backgroundImage: `url('https://image2url.com/images/1765276755489-216c3a78-7cd6-45c5-9971-a628f72ed61b.jpg')`, backgroundSize: 'cover', backgroundPosition: 'center' }}>
        <div className="absolute inset-0 bg-black/80 backdrop-blur-md z-0"></div>
        <div className="z-10 flex flex-col items-center max-w-sm w-full text-center p-8 rounded-3xl bg-black/40 border border-white/5 backdrop-blur-xl shadow-2xl">
          <div className="w-24 h-24 mb-6 rounded-full bg-purple-900/40 flex items-center justify-center border border-purple-500/30">
             <MapPin size={48} className={gpsStatus === 'checking' ? 'text-purple-400 animate-bounce' : 'text-purple-500'} />
          </div>
          
          {gpsStatus === 'idle' && (
            <>
              <h2 className="text-2xl font-bold mb-4 text-white">ڕێگەپێدانی شوێن</h2>
              <p className="text-gray-300 text-sm mb-8 leading-relaxed">ئەم ئەپە تەنها بۆ بەکارهێنەرانی ناوخۆی عێراقە. تکایە ڕێگە بدە بە دۆزینەوەی شوێنەکەت بۆ بەردەوام بوون.</p>
              <button 
                onClick={requestLocation}
                className="w-full bg-purple-600 hover:bg-purple-500 text-white font-bold py-4 rounded-xl transition shadow-[0_0_20px_rgba(147,51,234,0.4)] flex justify-center items-center gap-2"
              >
                <MapPin size={20} />
                پێدانی ڕێگەپێدان
              </button>
            </>
          )}

          {gpsStatus === 'checking' && (
            <>
              <h2 className="text-2xl font-bold mb-2">لە پشکنیندایە...</h2>
              <p className="text-purple-300 text-sm">چاوەڕێی وەڵامی مۆبایلەکەتین</p>
            </>
          )}
          
          {gpsStatus === 'failed' && (
            <div className="flex flex-col items-center w-full">
              <h2 className="text-xl font-bold text-red-400 mb-3">کێشە لە شوێنەکەت هەیە</h2>
              <p className="text-gray-300 text-sm mb-6">بەداخەوە ناتوانیت لە دەرەوەی عێراق بەکاری بهێنیت، یان ڕێگەت نەداوە بە شوێنپێهەڵگرتن لە ڕێکخستنەکانی مۆبایلەکەت.</p>
              <button 
                onClick={requestLocation}
                className="w-full bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold py-3 rounded-xl transition"
              >
                دووبارە هەوڵبدەرەوە
              </button>
            </div>
          )}

          {gpsStatus === 'passed' && (
            <div className="flex flex-col items-center w-full">
               <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mb-4 border border-green-500/50">
                 <Shield className="text-green-400" size={32} />
               </div>
              <h2 className="text-xl font-bold text-green-400">سەرکەوتوو بوو!</h2>
              <p className="text-gray-400 text-sm mt-2">بەخێربێیت بۆ ناو ئەپەکە</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  if (stage === 'activation') {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center p-6 text-white relative">
        <div className="absolute inset-0 bg-gradient-to-br from-[#1a0033] to-black z-0"></div>
        <div className="z-10 w-full max-w-sm glass-panel p-8 rounded-3xl border border-purple-500/30 bg-black/60 backdrop-blur-xl">
          <img src="https://image2url.com/images/1765276673899-f93a46b6-20a3-454c-ac94-202022d4dd2d.png" className="w-24 h-24 mx-auto mb-6" alt="Logo"/>
          <h2 className="text-2xl font-bold text-center mb-6">کۆدی چالاککردن</h2>
          <input 
            type="text" 
            value={activationCode}
            onChange={(e) => setActivationCode(e.target.value)}
            placeholder="کۆد لێرە بنووسە..."
            className="w-full bg-black/50 border border-purple-500/50 rounded-xl p-4 text-center text-xl text-white focus:outline-none focus:border-purple-300 mb-6"
            dir="ltr"
          />
          <button 
            onClick={handleActivation}
            className="w-full bg-purple-600 hover:bg-purple-500 text-white font-bold py-4 rounded-xl transition shadow-[0_0_20px_rgba(147,51,234,0.4)]"
          >
            چالاککردن
          </button>
        </div>
      </div>
    );
  }

  // --- Main UI ---
  const filteredChannels = channels.filter(c => 
    (c.title || '').toLowerCase().includes((searchQuery || '').toLowerCase()) &&
    (activeCategory === 'هەمووی' || ((c as any).category || 'گشتی') === activeCategory)
  );

  return (
    <div className="min-h-screen bg-black text-white pb-24 relative" style={{ backgroundImage: `url('https://image2url.com/images/1765276755489-216c3a78-7cd6-45c5-9971-a628f72ed61b.jpg')`, backgroundAttachment: 'fixed', backgroundSize: 'cover' }}>
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/90 to-black z-0 pointer-events-none"></div>
      
      {/* Video Player */}
      {playingChannel && (
        <VideoPlayer 
          channel={playingChannel} 
          channels={channels} 
          onSelectChannel={setPlayingChannel} 
          onClose={() => setPlayingChannel(null)} 
        />
      )}

      {/* Header */}
      <div className="sticky top-0 z-40 bg-black/80 backdrop-blur-xl border-b border-white/5 px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3 w-full">
          <img src="https://image2url.com/images/1765276673899-f93a46b6-20a3-454c-ac94-202022d4dd2d.png" alt="Logo" className="w-10 h-10"/>
          <div className="relative flex-1">
            <input 
              type="text" 
              placeholder="گەڕان بەدوای کەناڵ..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white/10 border border-white/5 rounded-full py-2.5 px-10 text-sm focus:outline-none focus:bg-white/20 transition"
            />
            <Search className="absolute right-3 top-2.5 text-gray-400 w-5 h-5" />
          </div>
        </div>
      </div>

      <div className="relative z-10 p-4">
        {/* Banner (Visible on Home) */}
        {activeTab === 'home' && (
          <div className="w-full h-40 bg-gradient-to-r from-purple-900 to-indigo-900 rounded-3xl mb-6 overflow-hidden relative shadow-2xl border border-white/10">
            <div className="absolute inset-0 flex items-center p-6">
               <div className="z-10">
                 <h2 className="text-2xl font-bold font-sans tracking-wider text-yellow-400 drop-shadow-md">بۆ ڕێکلام کردن</h2>
                 <p className="text-sm mt-2 text-purple-200" dir="ltr">@raid_amin</p>
               </div>
            </div>
            {/* Design accents */}
            <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-purple-500 rounded-full blur-3xl opacity-40"></div>
          </div>
        )}

        {/* Categories Bar */}
        {activeTab === 'home' && (
          <div className="flex overflow-x-auto gap-2 pb-2 mb-6 scrollbar-hide -mx-4 px-4">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`whitespace-nowrap px-5 py-2 rounded-full text-sm font-bold transition-all ${activeCategory === cat ? 'bg-purple-600 text-white shadow-[0_0_10px_rgba(147,51,234,0.5)]' : 'bg-white/10 text-gray-300 hover:bg-white/20 border border-white/5'}`}
              >
                {cat}
              </button>
            ))}
          </div>
        )}

        {/* Content based on tab */}
        {activeTab === 'home' && (
           <>
             <h3 className="text-xl font-bold mb-4 text-purple-100 flex items-center gap-2">
               <Play size={20} className="text-purple-500" />
               هەموو کەناڵەکان
             </h3>
             {filteredChannels.length === 0 ? (
               <div className="text-center text-gray-500 py-10">چاوەڕێی کەناڵەکان...</div>
             ) : (
               <div className="grid grid-cols-3 gap-3">
                 {filteredChannels.map(ch => (
                   <ChannelCard 
                     key={ch.id} 
                     channel={ch} 
                     isFavorite={favorites.includes(ch.id)} 
                     onToggleFavorite={(e) => toggleFavorite(ch.id, e)} 
                     onClick={() => setPlayingChannel(ch)} 
                   />
                 ))}
               </div>
             )}
           </>
        )}

        {activeTab === 'favorites' && (
           <>
             <h3 className="text-xl font-bold mb-4 text-purple-100 flex items-center gap-2">
               <Heart size={20} className="text-purple-500" />
               دڵخوازەکان
             </h3>
             {favorites.length === 0 ? (
               <div className="text-center text-gray-500 py-10">هیچ کەناڵێکی دڵخوازت نییە</div>
             ) : (
               <div className="grid grid-cols-3 gap-3">
                 {channels.filter(c => favorites.includes(c.id) && (c.title || '').toLowerCase().includes((searchQuery || '').toLowerCase())).map(ch => (
                   <ChannelCard 
                     key={ch.id} 
                     channel={ch} 
                     isFavorite={true} 
                     onToggleFavorite={(e) => toggleFavorite(ch.id, e)} 
                     onClick={() => setPlayingChannel(ch)} 
                   />
                 ))}
               </div>
             )}
           </>
        )}

        {activeTab === 'location' && (
          <div className="p-4 flex flex-col items-center justify-center text-center py-20">
            <div className="w-32 h-32 bg-green-500/20 rounded-full flex items-center justify-center mb-6 border border-green-500/50 relative">
               <div className="absolute inset-0 bg-green-500 blur-2xl opacity-20 rounded-full"></div>
               <MapPin size={48} className="text-green-500" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">شوێنەکەت پشتڕاستکراوەتەوە</h2>
            <p className="text-gray-400">تۆ لەناو عێراقیت، دەتوانیت سوود لە خزمەتگوزارییەکان ببینیت.</p>
          </div>
        )}

        {activeTab === 'profile' && (
          <div className="flex flex-col h-[60vh]">
            <div className="flex-1">
              <div className="flex items-center gap-4 mb-8 bg-white/5 p-4 rounded-2xl border border-white/10">
                 <div className="w-16 h-16 bg-purple-900 rounded-full flex items-center justify-center border-2 border-purple-500">
                   <User size={32} className="text-purple-300" />
                 </div>
                 <div>
                   <h2 className="font-bold text-xl">بەکارهێنەر</h2>
                   <p className="text-green-400 text-sm">چالاککراوە <span className="text-gray-500 ml-1">(Pro)</span></p>
                 </div>
              </div>

              <div className="space-y-4">
                <button className="w-full flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/10 hover:bg-white/10 transition">
                  <div className="flex items-center gap-3">
                    <Shield className="text-purple-400" />
                    <span>سیاسەتی تایبەتمەندی (Privacy Policy)</span>
                  </div>
                </button>
              </div>
            </div>

            <div className="text-center pb-8 mt-auto">
              <span className="text-sm font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-indigo-400" style={{ textShadow: '0 0 10px rgba(168, 85, 247, 0.5)' }}>
                گەشەپێدەر ڕائد ئەمین
              </span>
            </div>
          </div>
        )}
      </div>

      {/* iOS Style Bottom Nav */}
      <div className="fixed bottom-0 left-0 right-0 z-40 px-4 pb-6 pt-2 bg-black/60 backdrop-blur-[50px] border-t border-white/10">
        <div className="flex justify-around items-center">
          <NavBtn icon={<User size={24} />} label="هەژمار" isActive={activeTab === 'profile'} onClick={() => setActiveTab('profile')} />
          <NavBtn icon={<MapPin size={24} />} label="شوێن" isActive={activeTab === 'location'} onClick={() => setActiveTab('location')} />
          <NavBtn icon={<Heart size={24} />} label="دڵخواز" isActive={activeTab === 'favorites'} onClick={() => setActiveTab('favorites')} />
          <NavBtn icon={<HomeIcon size={24} />} label="سەرەتا" isActive={activeTab === 'home'} onClick={() => setActiveTab('home')} />
        </div>
        {/* iOS Home Indicator Bar */}
        <div className="w-1/3 h-1 bg-white/50 rounded-full mx-auto mt-4"></div>
      </div>
    </div>
  );
}

function NavBtn({ icon, label, isActive, onClick }: { icon: React.ReactNode, label: string, isActive: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`flex flex-col items-center gap-1.5 transition-colors ${isActive ? 'text-purple-400' : 'text-gray-500'}`}
    >
      <div className={`transition-transform duration-300 ${isActive ? 'scale-110 drop-shadow-[0_0_8px_rgba(168,85,247,0.8)]' : ''}`}>
        {icon}
      </div>
      <span className="text-[10px] font-bold">{label}</span>
    </button>
  );
}

