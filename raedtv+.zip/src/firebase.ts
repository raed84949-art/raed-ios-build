import { initializeApp } from 'firebase/app';
import { getDatabase } from 'firebase/database';

const firebaseConfig = {
  apiKey: "AIzaSyCKpHiuyd8I7k1C9mex_Gh4QKl1tJFw3WE",
  authDomain: "dramay-turke.firebaseapp.com",
  databaseURL: "https://dramay-turke-default-rtdb.firebaseio.com",
  projectId: "dramay-turke",
  storageBucket: "dramay-turke.firebasestorage.app",
  messagingSenderId: "60044386894",
  appId: "1:60044386894:web:1ed5e77ec3e09a4801591f"
};

const app = initializeApp(firebaseConfig);
export const rtdb = getDatabase(app);
